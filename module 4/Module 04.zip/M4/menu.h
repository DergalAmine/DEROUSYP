#pragma once

#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Windows.h>
#include "action.h"

// La Fonction principale affiche le menu et gere les appels des fonctions
void showMenu(struct PoulDonnees listePoul[], int *tailleTab);
